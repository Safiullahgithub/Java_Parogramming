package com.lq.exercises;

public interface ThreeDimensional {
	public double getVolume();
	public double getSurfaceArea();
}
