package com.lq.exercises;

public interface TwoDimensional {
	public double getArea();
	public double getPerimeter();
}
